﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Firebase.Auth;
using Firebase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DevConnect.Common
{
    public class FirebaseRepository
    {

        public static FirebaseAuth getFirebaseAuth()
        {
            //app instance
            var app = FirebaseApp.InitializeApp(Application.Context);

            if (app == null)
            {
                var options = new FirebaseOptions.Builder()
                   .SetProjectId("onlyfriends-6e3f9")
                   .SetApplicationId("1:964033776824:android:c05fc326cb0af21b9cb84d")
                   .SetApiKey("AIzaSyCDwLud1suHml9ADExF1NtGittYDVkCAL4")
                   .SetStorageBucket("onlyfriends-6e3f9.appspot.com")
                   .Build();

                app = FirebaseApp.InitializeApp(Application.Context, options);

            }


            return FirebaseAuth.GetInstance(app);

        }
    }
}